GRILL ARABIA — ANDROID STARTER PROJECT

This is a customized starter project for Grill Arabia in Poondi, Tamil Nadu. It includes a black-and-yellow themed menu, cart, and WhatsApp order-request flow.

MENU PRICES
The menu items and prices were transcribed from the menu image supplied in chat. Please verify them before publishing.

CONTACTS
Restaurant phone: +91 84895 46495
WhatsApp ordering: +91 77360 94215

HOW TO BUILD
1. Install Android Studio on a computer.
2. Extract this ZIP and open the folder as an existing project.
3. Allow Gradle to sync, then test on a device/emulator.
4. Use Android Studio > Build > Generate Signed Bundle / APK to create a signed Android App Bundle (.aab).
5. Complete Play Console listing, privacy, testing, and policy requirements before release.

IMPORTANT LIMITATIONS
This is a starter project, not a finished production app, signed APK/AAB, or published Play Store app. It currently supports a local demo menu/cart and WhatsApp order request. It does NOT include customer accounts, backend/database, restaurant admin dashboard, verified online payments, push notifications, or live delivery tracking. Online payments require a payment provider and secure backend integration. Dine-in is represented as an order type; table/QR ordering is not implemented. Delivery/takeaway details need to be finalized and tested.

Orders sent through WhatsApp are requests only; the restaurant must confirm them. Verify the menu and both phone numbers before launch.
